import axios from 'axios';
import { useState, useEffect } from 'react';
import { useNavigate, useLocation } from "react-router-dom";

import Search from '../components/Search';
import Header from '../components/Header';
import Posts from '../components/Posts';
import Pagination from '../components/Pagination';

const Table = () => {
    const navigate = useNavigate()
    const location = useLocation();

    const [filterIdFlag, setFilterIdFlag] = useState(false);
    const [filterTitleFlag, setFilterTitleFlag] = useState(false);
    const [filterDescriptionFlag, setFilterDescriptionFlag] = useState(false);

    const [data, setData] = useState([]);
    const [currentPage, setCurrentPage] = useState(1);
    const [posts] = useState(10);
    const [postsCurrent, setPostsCurrent] = useState([]);
    const [searchingData, setSearchingData] = useState('')


    useEffect(() => {
       if (location.pathname === '/') { navigate('/1')};
        const addressParam = Number(location.pathname.replace('/','').split());
        setCurrentPage(addressParam);
    }, [location]);

    useEffect(() => {
        getData();
    }, []);

    useEffect(() => {
        const lastPageIndex = currentPage*posts;
        const firstPageIndex = lastPageIndex - posts;
        const postsTempory = data.slice(firstPageIndex, lastPageIndex);
        setPostsCurrent(postsTempory)
    }, [data, currentPage]);

    const getData = async () => {
        // setLoading(true);
        const res = await axios.get('https://jsonplaceholder.typicode.com/posts');
        setData(res.data);
        // setLoading(false);
    }

    const search = (input) => {
        setSearchingData(input);
        console.log(input)
        const filtredData = data.filter((ite) => {
            return ite.title.toLowerCase().includes(searchingData.toLowerCase()) 
        }) 

        setCurrentPage(1);
        navigate(`/1`);
        console.log(filtredData);
       
        const lastPageIndex = currentPage*posts;
        const firstPageIndex = lastPageIndex - posts;
    
        const postsTempory = filtredData.slice(firstPageIndex, lastPageIndex);
            setPostsCurrent(postsTempory);
    }

    const paginate = async (number) => {
        navigate(`/${number}`);
        setCurrentPage(number);
        
    }

    const filterId = async () => {
        let sortArr = [];
        if (!filterIdFlag) {
            setFilterIdFlag(true);
             sortArr = await data.sort((a, b) => b.id - a.id)
        } else {
            setFilterIdFlag(false);
            sortArr = await data.sort((a, b) => a.id - b.id);
        }
      
        setData(sortArr);
        const lastPageIndex = currentPage*posts;
        const firstPageIndex = lastPageIndex - posts;
        const postsCurrent = data.slice(firstPageIndex, lastPageIndex);
        setPostsCurrent(postsCurrent)
        
    }
    const filterTitle = async () => {
        let sortArr = [];
        if (!filterTitleFlag) {
            setFilterTitleFlag(true);
             sortArr = await data.sort((a, b) => a.title > b.title ? 1 : -1);
        } else {
            setFilterTitleFlag(false);
            sortArr = await data.sort((a, b) => a.title > b.title ? - 1 : 1);
        }
      
        setData(sortArr);
        const lastPageIndex = currentPage*posts;
        const firstPageIndex = lastPageIndex - posts;
        const postsCurrent = data.slice(firstPageIndex, lastPageIndex);
        setPostsCurrent(postsCurrent)
        
    }
    const filterDescription = async () => {
        let sortArr = [];
        if (!filterDescriptionFlag) {
            setFilterDescriptionFlag(true);
             sortArr = await data.sort((a, b) => a.body > b.body ? 1 : -1);
        } else {
            setFilterDescriptionFlag(false);
            sortArr = await data.sort((a, b) => a.body > b.body ? - 1 : 1);
        }
      
        setData(sortArr);
        const lastPageIndex = currentPage*posts;
        const firstPageIndex = lastPageIndex - posts;
        const postsCurrent = data.slice(firstPageIndex, lastPageIndex);
        setPostsCurrent(postsCurrent)
        
    }

    return (
        <div className='table'>
            <Search search={search}/>
            <Header 
                filterId={filterId} 
                filterTitle={filterTitle} 
                filterDescription={filterDescription} 
                filterIdFlag={filterIdFlag}
                filterTitleFlag={filterTitleFlag}
                filterDescriptionFlag={filterDescriptionFlag}/>
            <Posts postsCurrent={postsCurrent}/>
            <Pagination 
                posts={posts} 
                data={data} 
                paginate={paginate} 
                currentPage={currentPage}/>
        </div>
    )
}

export default Table;