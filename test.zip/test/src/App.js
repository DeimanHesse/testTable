import Table from './pages/Table';
import { BrowserRouter } from 'react-router-dom'
import './app.scss';

function App() {
  return (
    <BrowserRouter>
    <div className="app">
      <Table/>
    </div>
    </BrowserRouter>
  );
}

export default App;
