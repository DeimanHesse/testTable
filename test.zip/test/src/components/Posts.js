const Posts = ({postsCurrent}) => {
    return (
        <div className="posts">
            <table>
                {postsCurrent.map((user, index) => {
                    return (
                        <tbody key={index}>
                        <tr>
                            <td className="posts__id" >{user.id}</td>
                            <td className="posts__title"style={{width:'60%'}}>{user.title}</td>
                            <td className="posts__description" style={{width:'30%'}}>{user.body}</td>
                        </tr>
                    </tbody>
                    )
                })}
            </table>
        </div>
    )
}

export default Posts;