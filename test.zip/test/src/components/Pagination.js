
const Pagination = ({data, posts, paginate, currentPage}) => {
    const pageNumbers = [];

    for (let index = 1; index <= Math.ceil(data.length/posts); index++) {
        pageNumbers.push(index)
    }

    const goBack = () => {
        let countBack = currentPage - 1;
        if (countBack < 1) {
            countBack = pageNumbers.length;
        }

        paginate(countBack);
    }

    const goForward = () => {
        let countForward = currentPage + 1;
        if (countForward > pageNumbers.length) {
            countForward = 1;
        }
        paginate(countForward)
    }
   

    return (
        <div className="pagination">
            <div onClick={goBack} className="pagination__button">Назад</div>
                <div className="pagination__pageNumbers">
                    {pageNumbers.map((number,index) => (
                        <div style={{
                                        cursor: 'pointer',
                                        listStyleType:'none',
                                        marginRight:10,
                                        
                                        }} 
                                    className={number === currentPage ? "active-link" : "link"}    
                                    key={index}
                                    onClick={() => paginate(number)} 
                                >{number}</div>
                            ))
                        }
                </div>
                
            <div onClick={goForward} className="pagination__button">Вперёд</div>
        </div>
    )
}

export default Pagination;