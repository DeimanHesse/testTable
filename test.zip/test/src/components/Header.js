import line from "../pic/Line23.png"
import arrow from "../pic/arrow.svg"


const Header = ({filterId, 
                filterTitle, 
                filterDescription,
                filterIdFlag,
                filterTitleFlag, 
                filterDescriptionFlag,
               
            }) => {
    return (
        <div className="header">
            <div className="header__item " 
                onClick={filterId} 
               
                style={{width:'10%', cursor:'pointer'}}>
                <div className="header__title">ID</div>
                <div className={filterIdFlag ? "header__pic active" : "header__pic"}>
                    <img src={arrow} alt="" />
                </div>
            </div>
            <div className="header__item " onClick={filterTitle} style={{width:'60%', cursor:'pointer'}}>
                <div className="header__title">Заголовок</div>
                <div className={filterTitleFlag ? "header__pic active" : "header__pic"}>
                    <img src={arrow} alt="" />
                </div>
            </div>
            <div className="header__item " onClick={filterDescription} style={{width:'30%', cursor:'pointer'}}>
                <div className="header__title">Описание</div>
                <div className={filterDescriptionFlag ? "header__pic active" : "header__pic"}>
                    <img src={arrow} alt="" />
                </div>
            </div>
        </div>
    )
}

export default Header;

