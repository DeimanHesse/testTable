import searchIcon from "../pic/search.svg"


const Search = ({search}) => {
    return (
        <div className="search">
            <input onChange={(e) => search(e.target.value)}
               placeholder="Поиск"
             type="text" />
             <div className="search__icon">
                 <img src={searchIcon} alt="" />
             </div>
        </div>
    )
}

export default Search;